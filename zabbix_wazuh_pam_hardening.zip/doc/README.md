# Zabbix & Wazuh PAM/LDAP Hardening Module

## Componentes incluídos

- `pam_configs/pam_sudo.conf`: Exemplo de configuração para `/etc/pam.d/sudo`
- `pam_configs/group.conf`: Configuração para `/etc/security/group.conf`
- `scripts/install_check.sh`: Script para validação local PAM + grupo
- `logs/`: Pasta destinada aos logs de execução
- `doc/README.md`: Este documento

## Como usar

1. Copie `pam_sudo.conf` para `/etc/pam.d/sudo` (faça backup antes)
2. Copie `group.conf` para `/etc/security/group.conf`
3. Execute `scripts/install_check.sh` como root
4. Verifique os logs gerados em `/var/log/zbx_wazuh_installer.log`

## Requisitos

- Sistema com PAM e LDAP configurados corretamente
- Grupo `zabbix-installers` local e grupo `ADMIN` no LDAP
- Executar apenas como `root`
