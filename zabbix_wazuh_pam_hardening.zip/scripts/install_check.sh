#!/bin/bash

LOG_FILE="/var/log/zbx_wazuh_installer.log"

if [ "$EUID" -ne 0 ]; then
  echo "[ERRO] Execute como root."
  exit 1
fi

if ! id -nG "$USER" | grep -qw "zabbix-installers"; then
  echo "[ERRO] Usuário $USER não pertence ao grupo zabbix-installers (validado via LDAP/PAM)."
  logger -p authpriv.warning "[ZBX-WAZUH-INSTALLER] Tentativa de execução indevida por $USER"
  exit 2
fi

echo "$(date +%F\ %T) | Usuário $USER iniciou execução." >> $LOG_FILE
logger -p auth.info "[ZBX-WAZUH-INSTALLER] Execução autorizada por $USER"

echo "[OK] Execução permitida. Continuando..."
