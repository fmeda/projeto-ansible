#!/bin/bash
# Vault loader example

export VAULT_ADDR='http://127.0.0.1:8200'
vault login <TOKEN>

LDAP_USER=$(vault kv get -field=ldap_user secret/zbxwazuh)
LDAP_PASS=$(vault kv get -field=ldap_pass secret/zbxwazuh)

echo "LDAP_USER: $LDAP_USER"
# Uso seguro das variáveis continua aqui...
