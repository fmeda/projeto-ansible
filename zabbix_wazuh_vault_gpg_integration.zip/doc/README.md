# Zabbix & Wazuh Vault/GPG Integration

## Objetivo
Proteger credenciais sensíveis (como LDAP, Zabbix e Wazuh) usando:

- 🔐 [HashiCorp Vault](https://www.vaultproject.io/)
- 🔑 GPG (GNU Privacy Guard)

## 1. Vault KV Secrets Engine (exemplo)

```bash
vault kv put secret/zbxwazuh ldap_user='admin' ldap_pass='segredo123'
```

## 2. No script (exemplo):

```bash
LDAP_USER=$(vault kv get -field=ldap_user secret/zbxwazuh)
LDAP_PASS=$(vault kv get -field=ldap_pass secret/zbxwazuh)
```

## 3. Alternativa com GPG:

```bash
gpg -c secrets.env
gpg secrets.env.gpg
source secrets.env
```

## Segurança
- Armazene `.gpg` em local seguro e nunca envie `secrets.env` diretamente.
- Use tokens Vault com TTL e políticas restritivas.

## Pré-requisitos

- Vault CLI instalado e configurado (`vault auth`)
- GPG configurado com chave pessoal
